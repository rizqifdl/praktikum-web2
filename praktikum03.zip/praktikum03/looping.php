<?php 

// buat loop for 
for ($i=1; $i <= 10; $i++) { 
    // code looping
    echo $i . "<br>";
}

// buat loop array
$buah = ["anggur", "apel", "melon"];
// loop array
foreach ($buah as $b) {
    // code looping
    echo $b . "<br>";
}

?>