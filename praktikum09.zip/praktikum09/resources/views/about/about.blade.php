<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Laravel</title>
</head>
<body>
    <h1>About</h1>

    <p>Ini adalah halaman About.</p>

    <p>Nama: {{ $nama }}</p>
    <p>NIM: {{ $nim }}</p>
    <p>Program Studi: {{ $program_studi }}</p>
    <p>Tahun Angkatan: {{ $tahun_angkatan }}</p>
</body>
</html>
