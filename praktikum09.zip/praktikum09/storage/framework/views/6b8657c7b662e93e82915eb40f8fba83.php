<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Laravel</title>
</head>
<body>
    <h1>About</h1>

    <p>Ini adalah halaman About.</p>

    <p>Nama: <?php echo e($nama); ?></p>
    <p>NIM: <?php echo e($nim); ?></p>
    <p>Program Studi: <?php echo e($program_studi); ?></p>
    <p>Tahun Angkatan: <?php echo e($tahun_angkatan); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Praktikum-web2\praktikum09\resources\views/about/about.blade.php ENDPATH**/ ?>